/*
 *  Surgery.h
 *  Patient Fees
 *
 *  Created by Devan Beitel on 11/23/10.
 *  Copyright 2010 FindMySpace. All rights reserved.
 *
 */

#ifndef Surgery_H
#define Surgery_H

//Surgery class declaration

class Surgery
{
private:
    double c_surg1;
    double c_surg2;
    double c_surg3;
    double c_surg4;
    double c_surg5;
    double c_surgCosts;
public:
    Surgery();
    void setSurg1(double); //Sets Surg1 price
    void setSurg2(double); //Sets Surg2 price
    void setSurg3(double); //Sets Surg3 price
    void setSurg4(double); //Sets Surg4 price
    void setSurg5(double); //Sets Surg5 price
    void addSurg1(); //Adds Surg1 price to c_surgCosts variable
    void addSurg2(); //Adds Surg2 price to c_surgCosts variable
    void addSurg3(); //Adds Surg3 price to c_surgCosts variable
    void addSurg4(); //Adds Surg4 price to c_surgCosts variable
    void addSurg5(); //Adds Surg5 price to c_surgCosts variable
    double getSurg1(); //Displays Surg1 price
    double getSurg2(); //Displays Surg2 price
    double getSurg3(); //Displays Surg3 price
    double getSurg4(); //Displays Surg4 price
    double getSurg5(); //Displays Surg5 price
};

#endif