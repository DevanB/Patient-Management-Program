/*
 *  Surgery.cpp
 *  Patient Fees
 *
 *  Created by Devan Beitel on 11/23/10.
 *  Copyright 2010 FindMySpace. All rights reserved.
 *
 */

//Implementation file for Surgery Class
#include "Surgery.h"
#include <iostream>
using namespace std;

Surgery::Surgery()
{
    c_surg1 = 5;
    c_surg2 = 10;
    c_surg3 = 15;
    c_surg4 = 20;
    c_surg5 = 25;
}

void Surgery::setSurg1(double surg1)
{
    c_surg1 = surg1;
}
void Surgery::setSurg2(double surg2)
{
    c_surg2 = surg2;
}
void Surgery::setSurg3(double surg3)
{
    c_surg3 = surg3;
}
void Surgery::setSurg4(double surg4)
{
    c_surg4 = surg4;
}
void Surgery::setSurg5(double surg5)
{
    c_surg5 = surg5;
}
void Surgery::addSurg1()
{
    c_surgCosts += c_surg1;
}
void Surgery::addSurg2()
{
    c_surgCosts += c_surg2;
}
void Surgery::addSurg3()
{
    c_surgCosts += c_surg3;
}
void Surgery::addSurg4()
{
    c_surgCosts += c_surg4;
}
void Surgery::addSurg5()
{
    c_surgCosts += c_surg5;
}
double Surgery::getSurg1()
{
    return c_surg1;
}
double Surgery::getSurg2()
{
    return c_surg2;
}
double Surgery::getSurg3()
{
    return c_surg3;
}
double Surgery::getSurg4()
{
    return c_surg4;
}
double Surgery::getSurg5()
{
    return c_surg5;
}