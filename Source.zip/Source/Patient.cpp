/*
 *  Patient.cpp
 *  Patient Fees
 *
 */

//Implementation file for Patient Class
#include "Patient.h"
#include <iostream>
using namespace std;

Patient::Patient(double daily)
{
	c_dailyRate = daily;
}
void Patient::setDays(int d)
{
	c_days = d;
}
void Patient::setDailyRate(double daily)
{
	c_dailyRate = daily;
}
void Patient::addCharges(double adtl)
{
    c_charges += adtl;
}
double Patient::getDailyRate()
{
    return c_dailyRate;
}
double Patient::getCharges()
{
	c_charges = c_dailyRate * c_days;
	return c_charges;
}
